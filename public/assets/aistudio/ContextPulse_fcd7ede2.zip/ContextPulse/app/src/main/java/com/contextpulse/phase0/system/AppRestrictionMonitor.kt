package com.contextpulse.phase0.system

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class InterceptionLogEntry(
    val timestampMs: Long,
    val packageName: String,
    val isRestricted: Boolean,
    val latencyMs: Long,
    val actionTaken: String,
    val success: Boolean
)

object AppRestrictionMonitor {

    private const val TAG = "AppRestrictionMonitor"

    private var monitorJob: Job? = null
    private val monitorScope = CoroutineScope(Dispatchers.Default)

    private val _isMonitoring = MutableStateFlow(false)
    val isMonitoring: StateFlow<Boolean> = _isMonitoring.asStateFlow()

    private val _lastDetectedApp = MutableStateFlow<String?>(null)
    val lastDetectedApp: StateFlow<String?> = _lastDetectedApp.asStateFlow()

    private val _lastLatencyMs = MutableStateFlow(0L)
    val lastLatencyMs: StateFlow<Long> = _lastLatencyMs.asStateFlow()

    private val _interceptionHistory = MutableStateFlow<List<InterceptionLogEntry>>(emptyList())
    val interceptionHistory: StateFlow<List<InterceptionLogEntry>> = _interceptionHistory.asStateFlow()

    private var targetRestrictedPackages = setOf(
        "com.instagram.android",
        "com.zhiliaoapp.musically", // TikTok
        "com.google.android.youtube"
    )

    fun setRestrictedPackages(packages: Set<String>) {
        targetRestrictedPackages = packages
    }

    fun getRestrictedPackages(): Set<String> = targetRestrictedPackages

    /**
     * Starts a continuous foreground app polling experiment.
     * Polling interval defaults to 1500ms to balance detection latency and battery impact.
     */
    fun startContinuousMonitoring(context: Context, intervalMs: Long = 1500L) {
        if (_isMonitoring.value) return
        if (!SystemControllers.hasUsageStatsPermission(context)) {
            Log.w(TAG, "Cannot start monitoring: PACKAGE_USAGE_STATS not granted")
            return
        }

        _isMonitoring.value = true
        monitorJob = monitorScope.launch {
            Log.d(TAG, "Started App Restriction polling experiment (interval=${intervalMs}ms)")

            var lastHandledApp: String? = null
            var lastHandledTimestamp = 0L

            while (isActive) {
                try {
                    val (currentApp, latency) = SystemControllers.getForegroundAppWithLatency(context)
                    if (currentApp != null && currentApp != context.packageName) {
                        _lastDetectedApp.value = currentApp
                        _lastLatencyMs.value = latency

                        val isRestricted = targetRestrictedPackages.contains(currentApp)

                        // Avoid repeatedly spamming overlay if already showing
                        val now = System.currentTimeMillis()
                        if (isRestricted && (currentApp != lastHandledApp || (now - lastHandledTimestamp) > 5000L)) {
                            lastHandledApp = currentApp
                            lastHandledTimestamp = now

                            val actionTaken = if (SystemControllers.canDrawOverlays(context)) {
                                try {
                                    SystemControllers.showRestrictionOverlay(context, currentApp)
                                    "Launched Blocker Overlay"
                                } catch (e: Exception) {
                                    "Failed launching overlay: ${e.message}"
                                }
                            } else {
                                SystemControllers.kickToHomeScreen(context)
                                "Overlay permission missing -> Kicked to Home"
                            }

                            val entry = InterceptionLogEntry(
                                timestampMs = now,
                                packageName = currentApp,
                                isRestricted = true,
                                latencyMs = latency,
                                actionTaken = actionTaken,
                                success = true
                            )
                            val list = _interceptionHistory.value.takeLast(40).toMutableList()
                            list.add(entry)
                            _interceptionHistory.value = list
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in restriction polling loop", e)
                }

                delay(intervalMs)
            }
        }
    }

    fun stopContinuousMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
        _isMonitoring.value = false
        Log.d(TAG, "Stopped App Restriction polling experiment")
    }
}
