package com.contextpulse.phase0.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.contextpulse.phase0.ble.BeaconRegistry
import com.contextpulse.phase0.ble.BleScanProfile
import com.contextpulse.phase0.ble.Phase0BleService
import com.contextpulse.phase0.model.*
import com.contextpulse.phase0.system.AppRestrictionMonitor
import com.contextpulse.phase0.system.SystemControllers
import com.contextpulse.phase0.system.XiaomiHyperOsHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF38BDF8),
                    secondary = Color(0xFF818CF8),
                    background = Color(0xFF0F172A),
                    surface = Color(0xFF1E293B),
                    onBackground = Color(0xFFF8FAFC),
                    onSurface = Color(0xFFF8FAFC)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Phase0NativeDashboard()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Phase0NativeDashboard() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }

    // Service State Flows
    val allDiscovered by Phase0BleService.allDiscoveredDevices.collectAsState()
    val registeredRooms by Phase0BleService.registeredRoomBeacons.collectAsState()
    val activeRoom by Phase0BleService.activeRoomBeacon.collectAsState()
    val scanProfile by Phase0BleService.currentScanProfile.collectAsState()
    val serviceLogs by Phase0BleService.serviceLogs.collectAsState()

    // Restriction Monitor Flow
    val isRestrictionMonitoring by AppRestrictionMonitor.isMonitoring.collectAsState()
    val lastDetectedApp by AppRestrictionMonitor.lastDetectedApp.collectAsState()
    val lastLatencyMs by AppRestrictionMonitor.lastLatencyMs.collectAsState()
    val interceptionHistory by AppRestrictionMonitor.interceptionHistory.collectAsState()

    // Real Permission States
    var hasBleScanPerm by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    var hasLocationPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasPostNotifPerm by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    var canWriteSettings by remember { mutableStateOf(SystemControllers.canModifySystemSettings(context)) }
    var isDndGranted by remember { mutableStateOf(SystemControllers.isDndAccessGranted(context)) }
    var hasUsageStats by remember { mutableStateOf(SystemControllers.hasUsageStatsPermission(context)) }
    var canDrawOverlays by remember { mutableStateOf(SystemControllers.canDrawOverlays(context)) }

    // Beacon Registration Dialog State
    var beaconToRegister by remember { mutableStateOf<BleBeaconInfo?>(null) }
    var customRoomNameInput by remember { mutableStateOf("Bedroom") }

    val runtimePermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            hasBleScanPerm = results[Manifest.permission.BLUETOOTH_SCAN] ?: hasBleScanPerm
        }
        hasLocationPerm = results[Manifest.permission.ACCESS_FINE_LOCATION] ?: hasLocationPerm
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPostNotifPerm = results[Manifest.permission.POST_NOTIFICATIONS] ?: hasPostNotifPerm
        }
    }

    var currentMonotonicMs by remember { mutableStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(1000)
            currentMonotonicMs = SystemClock.elapsedRealtime()
            canWriteSettings = SystemControllers.canModifySystemSettings(context)
            isDndGranted = SystemControllers.isDndAccessGranted(context)
            hasUsageStats = SystemControllers.hasUsageStatsPermission(context)
            canDrawOverlays = SystemControllers.canDrawOverlays(context)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("ContextPulse Phase 0", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            text = "POCO / HyperOS Native Capability Lab",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1E293B),
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = {
                        val serviceIntent = Intent(context, Phase0BleService::class.java).apply {
                            action = Phase0BleService.ACTION_START
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startForegroundService(serviceIntent)
                        } else {
                            context.startService(serviceIntent)
                        }
                        Toast.makeText(context, "Started Native BLE Service", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Start Service", tint = Color(0xFF10B981))
                    }
                    IconButton(onClick = {
                        val serviceIntent = Intent(context, Phase0BleService::class.java).apply {
                            action = Phase0BleService.ACTION_STOP
                        }
                        context.startService(serviceIntent)
                        Toast.makeText(context, "Stopped Native BLE Service", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop Service", tint = Color(0xFFEF4444))
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF1E293B)) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.BluetoothSearching, contentDescription = null) },
                    label = { Text("Radar") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Science, contentDescription = null) },
                    label = { Text("Capabilities") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Block, contentDescription = null) },
                    label = { Text("App Monitor") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Security, contentDescription = null) },
                    label = { Text("Permissions") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Terminal, contentDescription = null) },
                    label = { Text("Logs") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (selectedTab) {
                0 -> BleRadarScreen(
                    context = context,
                    allDiscovered = allDiscovered,
                    registeredRooms = registeredRooms,
                    activeRoom = activeRoom,
                    currentScanProfile = scanProfile,
                    currentMonotonicMs = currentMonotonicMs,
                    onSelectProfile = { profile ->
                        val intent = Intent(context, Phase0BleService::class.java).apply {
                            action = Phase0BleService.ACTION_SET_SCAN_PROFILE
                            putExtra(Phase0BleService.EXTRA_SCAN_PROFILE, profile.name)
                        }
                        context.startService(intent)
                    },
                    onRegisterBeacon = { beacon ->
                        beaconToRegister = beacon
                        customRoomNameInput = beacon.assignedRoomName ?: "Bedroom"
                    }
                )
                1 -> CapabilityTestingScreen(
                    context = context,
                    canWriteSettings = canWriteSettings,
                    isDndGranted = isDndGranted,
                    hasUsageStats = hasUsageStats,
                    canDrawOverlays = canDrawOverlays
                )
                2 -> AppRestrictionExperimentScreen(
                    context = context,
                    isMonitoring = isRestrictionMonitoring,
                    hasUsageStats = hasUsageStats,
                    canDrawOverlays = canDrawOverlays,
                    lastDetectedApp = lastDetectedApp,
                    lastLatencyMs = lastLatencyMs,
                    history = interceptionHistory,
                    onToggleMonitoring = {
                        if (isRestrictionMonitoring) {
                            AppRestrictionMonitor.stopContinuousMonitoring()
                        } else {
                            if (!hasUsageStats) {
                                SystemControllers.openUsageAccessSettings(context)
                            } else {
                                AppRestrictionMonitor.startContinuousMonitoring(context)
                            }
                        }
                    }
                )
                3 -> PermissionsAndHyperOsScreen(
                    context = context,
                    hasBleScan = hasBleScanPerm,
                    hasLocation = hasLocationPerm,
                    hasNotif = hasPostNotifPerm,
                    canWriteSettings = canWriteSettings,
                    isDndGranted = isDndGranted,
                    hasUsageStats = hasUsageStats,
                    canDrawOverlays = canDrawOverlays,
                    onRequestRuntimePerms = {
                        val perms = mutableListOf<String>()
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            perms.add(Manifest.permission.BLUETOOTH_SCAN)
                            perms.add(Manifest.permission.BLUETOOTH_CONNECT)
                        }
                        perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            perms.add(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        runtimePermLauncher.launch(perms.toTypedArray())
                    }
                )
                4 -> LogsScreen(logs = serviceLogs)
            }

            // Beacon Registration Dialog
            if (beaconToRegister != null) {
                AlertDialog(
                    onDismissRequest = { beaconToRegister = null },
                    title = { Text("Register Beacon to Room") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Assign this physical beacon to a room context. Only registered room beacons will be evaluated for active room selection.", fontSize = 13.sp, color = Color(0xFFCBD5E1))
                            Text("MAC: ${beaconToRegister!!.macAddress}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF38BDF8))
                            if (beaconToRegister!!.uuid != null) {
                                Text("UUID: ${beaconToRegister!!.uuid}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFA855F7))
                            }
                            OutlinedTextField(
                                value = customRoomNameInput,
                                onValueChange = { customRoomNameInput = it },
                                label = { Text("Room Name (e.g. Bedroom, Desk)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            BeaconRegistry.registerBeacon(
                                context = context,
                                roomName = customRoomNameInput.trim(),
                                macAddress = beaconToRegister!!.macAddress,
                                uuid = beaconToRegister!!.uuid,
                                major = beaconToRegister!!.major,
                                minor = beaconToRegister!!.minor
                            )
                            Toast.makeText(context, "Beacon registered to '${customRoomNameInput.trim()}'", Toast.LENGTH_SHORT).show()
                            beaconToRegister = null
                        }) {
                            Text("Save Room Beacon")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { beaconToRegister = null }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun BleRadarScreen(
    context: Context,
    allDiscovered: List<BleBeaconInfo>,
    registeredRooms: List<BleBeaconInfo>,
    activeRoom: BleBeaconInfo?,
    currentScanProfile: BleScanProfile,
    currentMonotonicMs: Long,
    onSelectProfile: (BleScanProfile) -> Unit,
    onRegisterBeacon: (BleBeaconInfo) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Active Room Banner (Evaluated ONLY from registered beacons)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Active Room Winner", fontSize = 12.sp, color = Color(0xFF94A3B8))
                        Surface(
                            color = if (activeRoom != null) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFFF59E0B).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                if (activeRoom != null) "LOCKED (+5dB Dwell)" else "SEARCHING",
                                color = if (activeRoom != null) Color(0xFF10B981) else Color(0xFFF59E0B),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = activeRoom?.let { "${it.assignedRoomName ?: it.name} (${it.macAddress})" } ?: "No Registered Room Beacon in Range",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeRoom != null) Color(0xFF10B981) else Color(0xFFF59E0B)
                    )
                    if (activeRoom != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Smoothed RSSI: ${activeRoom.smoothedRssi.toInt()} dBm • Est. Distance: ~${activeRoom.estimatedDistanceMeters}m",
                            fontSize = 12.sp,
                            color = Color(0xFF38BDF8)
                        )
                    }
                }
            }
        }

        // Scan Profile Selector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("BLE Scan Mode & Duty Cycle", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                    Text("Select profile to compare scanning responsiveness vs battery drain:", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BleScanProfile.values().forEach { profile ->
                            val isSelected = profile == currentScanProfile
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectProfile(profile) },
                                label = { Text(profile.name.replace("_", " "), fontSize = 11.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Text(currentScanProfile.dutyCycle, fontSize = 10.sp, color = Color(0xFF38BDF8), modifier = Modifier.padding(top = 4.dp))
                }
            }
        }

        // Section 1: Registered Room Beacons (Eligible for Room Switching)
        item {
            Text("Registered Room Beacons (${registeredRooms.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
            Text("Only these beacons can trigger room context changes:", fontSize = 11.sp, color = Color(0xFF94A3B8))
        }

        if (registeredRooms.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B).copy(alpha = 0.5f))) {
                    Text("No registered room beacons detected nearby.", fontSize = 12.sp, color = Color(0xFF94A3B8), modifier = Modifier.padding(12.dp))
                }
            }
        } else {
            items(registeredRooms) { beacon ->
                BeaconCard(beacon, currentMonotonicMs, isRegistered = true, onRegister = null)
            }
        }

        // Section 2: Other Discovered BLE Devices (Diagnostics & Registration)
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Other Nearby BLE Devices (${allDiscovered.size - registeredRooms.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
            Text("Ignored for room triggers. Tap 'Register' to designate as a room beacon:", fontSize = 11.sp, color = Color(0xFF94A3B8))
        }

        val unreg = allDiscovered.filter { !it.isRegisteredRoomBeacon }
        if (unreg.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B).copy(alpha = 0.5f))) {
                    Text("No additional BLE devices discovered.", fontSize = 12.sp, color = Color(0xFF94A3B8), modifier = Modifier.padding(12.dp))
                }
            }
        } else {
            items(unreg) { beacon ->
                BeaconCard(beacon, currentMonotonicMs, isRegistered = false, onRegister = { onRegisterBeacon(beacon) })
            }
        }
    }
}

@Composable
fun BeaconCard(
    beacon: BleBeaconInfo,
    currentMonotonicMs: Long,
    isRegistered: Boolean,
    onRegister: (() -> Unit)?
) {
    val secondsSinceSeen = ((currentMonotonicMs - beacon.lastSeenMonotonicMs) / 1000).coerceAtLeast(0)
    val isDisappearing = secondsSinceSeen >= 8

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isDisappearing) Color(0xFF2D1E2F) else Color(0xFF1E293B)
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(beacon.assignedRoomName ?: beacon.name ?: "Unknown Beacon", fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    "${beacon.smoothedRssi.toInt()} dBm (raw: ${beacon.rawRssi})",
                    color = Color(0xFF38BDF8),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Text(beacon.macAddress, fontSize = 11.sp, color = Color(0xFF94A3B8), fontFamily = FontFamily.Monospace)
            if (beacon.uuid != null) {
                Text(
                    "UUID: ${beacon.uuid} (M:${beacon.major ?: "?"} m:${beacon.minor ?: "?"})",
                    fontSize = 11.sp,
                    color = Color(0xFFA855F7),
                    fontFamily = FontFamily.Monospace
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Type: ${beacon.beaconType} • Dist: ~${beacon.estimatedDistanceMeters}m", fontSize = 11.sp, color = Color(0xFFCBD5E1))
                Text(
                    text = "Seen: ${secondsSinceSeen}s ago",
                    fontSize = 11.sp,
                    color = if (isDisappearing) Color(0xFFF43F5E) else Color(0xFF10B981),
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (onRegister != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = onRegister,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Register as Room Beacon", fontSize = 11.sp, color = Color(0xFF38BDF8))
                }
            }
        }
    }
}

@Composable
fun AppRestrictionExperimentScreen(
    context: Context,
    isMonitoring: Boolean,
    hasUsageStats: Boolean,
    canDrawOverlays: Boolean,
    lastDetectedApp: String?,
    lastLatencyMs: Long,
    history: List<com.contextpulse.phase0.system.InterceptionLogEntry>,
    onToggleMonitoring: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("App Restriction Feasibility Experiment (Task 3)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            Text(
                "Separates detection, matching, and response. Evaluates realistic polling latency vs instant blocking.",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
        }

        // Feasibility Warning Notice
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03).copy(alpha = 0.5f))) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("UNRESOLVED ANDROID LIMITATION:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFFF59E0B))
                    Text(
                        "Instantaneous 0ms pre-launch blocking is technically impossible for third-party consumer apps. UsageStats has a 1-3 second delay. The target app will briefly appear before the blocker overlay covers it.",
                        fontSize = 11.sp,
                        color = Color(0xFFFED7AA)
                    )
                }
            }
        }

        // Continuous Poller Control
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("Continuous Foreground Poller", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Text("Queries UsageStats every 1.5 seconds", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        }
                        Button(
                            onClick = onToggleMonitoring,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isMonitoring) Color(0xFFEF4444) else Color(0xFF10B981)
                            )
                        ) {
                            Text(if (isMonitoring) "Stop Poller" else "Start Poller")
                        }
                    }
                    if (isMonitoring) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Active App: ${lastDetectedApp ?: "None"} (Latency: ${lastLatencyMs}ms)", fontSize = 12.sp, color = Color(0xFF38BDF8), fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Manual Capability Sub-Tests
        item {
            Text("Individual Pipeline Steps", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
        }

        item {
            StepCard(
                step = "5A",
                title = "Detect Foreground App",
                desc = "Queries UsageStatsManager.queryEvents() once. Latency: ${lastLatencyMs}ms.",
                btn = "Query Once",
                onClick = {
                    val (app, lat) = SystemControllers.getForegroundAppWithLatency(context)
                    Toast.makeText(context, "App: $app (${lat}ms latency)", Toast.LENGTH_SHORT).show()
                }
            )
        }

        item {
            StepCard(
                step = "6A",
                title = "Test Blocker Overlay Interface",
                desc = "Displays OverlayBlockerActivity over the screen.",
                btn = if (canDrawOverlays) "Launch Overlay" else "Grant Overlay Perm",
                onClick = {
                    if (canDrawOverlays) {
                        SystemControllers.showRestrictionOverlay(context, "com.instagram.android")
                    } else {
                        SystemControllers.openOverlaySettings(context)
                    }
                }
            )
        }

        item {
            StepCard(
                step = "6B",
                title = "Test Home Screen Redirection",
                desc = "Sends Intent.CATEGORY_HOME as an immediate non-overlay restriction fallback.",
                btn = "Trigger Kick to Home",
                onClick = { SystemControllers.kickToHomeScreen(context) }
            )
        }

        // Live Interception History
        item {
            Text("Interception Event History (${history.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
        }

        if (history.isEmpty()) {
            item {
                Text("No restricted apps intercepted yet. Launch Instagram or TikTok with poller active.", fontSize = 11.sp, color = Color(0xFF64748B))
            }
        } else {
            items(history.reversed()) { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(entry.packageName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                            Text("${entry.latencyMs}ms delay", fontSize = 11.sp, color = Color(0xFFF59E0B), fontWeight = FontWeight.SemiBold)
                        }
                        Text("Action: ${entry.actionTaken}", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                }
            }
        }
    }
}

@Composable
fun StepCard(step: String, title: String, desc: String, btn: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)), shape = RoundedCornerShape(8.dp)) {
        Row(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text("Step $step: $title", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                Text(desc, fontSize = 11.sp, color = Color(0xFF94A3B8))
            }
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155))) {
                Text(btn, fontSize = 11.sp, color = Color(0xFF38BDF8))
            }
        }
    }
}

@Composable
fun CapabilityTestingScreen(
    context: Context,
    canWriteSettings: Boolean,
    isDndGranted: Boolean,
    hasUsageStats: Boolean,
    canDrawOverlays: Boolean
) {
    var dndOpResult by remember { mutableStateOf<ZenRuleOpResult?>(null) }
    var currentBrightness by remember { mutableStateOf<Int?>(null) }
    var lastSnapshot by remember { mutableStateOf<SystemStateSnapshot?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Real Native Android Capability Tests", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            Text("Directly calls Android SDK APIs. Real status and exceptions are returned.", fontSize = 12.sp, color = Color(0xFF94A3B8))
        }

        // Test 8: Modern AutomaticZenRule (Task 2)
        item {
            NativeTestCard(
                number = "8",
                title = "Do Not Disturb (AutomaticZenRule)",
                type = "Android 14/15 ZenRule API",
                typeColor = Color(0xFF10B981),
                desc = "Uses configurationActivity + null owner + setAutomaticZenRuleState(). Result: ${dndOpResult?.message ?: "Not tested yet"}",
                btnText = if (isDndGranted) (if (dndOpResult?.isActive == true) "Deactivate ZenRule" else "Activate ZenRule") else "Open DND Permission Settings",
                onAction = {
                    if (isDndGranted) {
                        val activate = !(dndOpResult?.isActive ?: false)
                        val res = SystemControllers.setAutomaticZenRuleState(context, "ContextPulse Bedroom Rule", activate)
                        dndOpResult = res
                        Toast.makeText(context, res.message, Toast.LENGTH_SHORT).show()
                    } else {
                        SystemControllers.openDndAccessSettings(context)
                    }
                }
            )
        }

        // Test 7: Modify Screen Brightness
        item {
            NativeTestCard(
                number = "7",
                title = "Modify Screen Brightness",
                type = "Native API (Write Settings)",
                typeColor = Color(0xFFF59E0B),
                desc = "Calls Settings.System.putInt(SCREEN_BRIGHTNESS) with MANUAL mode. Requires WRITE_SETTINGS. Value: ${currentBrightness ?: "Not checked"}",
                btnText = if (canWriteSettings) "Set Brightness to 25%" else "Grant Write Settings",
                onAction = {
                    if (canWriteSettings) {
                        val ok = SystemControllers.setScreenBrightness(context, 64)
                        currentBrightness = 64
                        Toast.makeText(context, "Brightness written: $ok", Toast.LENGTH_SHORT).show()
                    } else {
                        SystemControllers.openWriteSettings(context)
                    }
                }
            )
        }

        // Test 10: Launch Another App
        item {
            NativeTestCard(
                number = "10",
                title = "Launch External App",
                type = "Native Intent (Scoped Queries)",
                typeColor = Color(0xFF10B981),
                desc = "Launches an external application using packageManager.getLaunchIntentForPackage without rejected QUERY_ALL_PACKAGES.",
                btnText = "Launch Settings App",
                onAction = {
                    val launched = SystemControllers.launchAppByPackage(context, "com.android.settings")
                    Toast.makeText(context, "Launched: $launched", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Test 14: System State Snapshot & Restoration
        item {
            NativeTestCard(
                number = "14",
                title = "State Snapshot & Restoration",
                type = "On-Device State Engine",
                typeColor = Color(0xFF10B981),
                desc = "Saves current brightness, DND filter, and ringer mode to memory. Restores baseline upon room exit. Snapshot: ${if (lastSnapshot != null) "Captured" else "Empty"}",
                btnText = if (lastSnapshot == null) "Capture State Snapshot" else "Restore Baseline Snapshot",
                onAction = {
                    if (lastSnapshot == null) {
                        lastSnapshot = SystemControllers.takeSystemStateSnapshot(context)
                        Toast.makeText(context, "Baseline captured!", Toast.LENGTH_SHORT).show()
                    } else {
                        val ok = SystemControllers.restoreSystemState(context, lastSnapshot!!)
                        lastSnapshot = null
                        Toast.makeText(context, "Restored state: $ok", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }
}

@Composable
fun NativeTestCard(
    number: String,
    title: String,
    type: String,
    typeColor: Color,
    desc: String,
    btnText: String,
    onAction: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Test #$number: $title", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                Surface(
                    color = typeColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        type,
                        color = typeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(desc, fontSize = 12.sp, color = Color(0xFF94A3B8))
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(btnText, color = Color(0xFF38BDF8), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun PermissionsAndHyperOsScreen(
    context: Context,
    hasBleScan: Boolean,
    hasLocation: Boolean,
    hasNotif: Boolean,
    canWriteSettings: Boolean,
    isDndGranted: Boolean,
    hasUsageStats: Boolean,
    canDrawOverlays: Boolean,
    onRequestRuntimePerms: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Permissions Status Matrix", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            Text(
                "Real runtime permission states queried from Android PackageManager & AppOpsManager.",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
        }

        item {
            Button(
                onClick = onRequestRuntimePerms,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Security, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Request Runtime Permissions (BLE & Location)")
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PermRow("BLUETOOTH_SCAN", hasBleScan)
                    PermRow("ACCESS_FINE_LOCATION", hasLocation)
                    PermRow("POST_NOTIFICATIONS", hasNotif)
                    PermRow("WRITE_SETTINGS (Brightness)", canWriteSettings)
                    PermRow("ACCESS_NOTIFICATION_POLICY (DND)", isDndGranted)
                    PermRow("PACKAGE_USAGE_STATS (App Detection)", hasUsageStats)
                    PermRow("SYSTEM_ALERT_WINDOW (Overlay Blocker)", canDrawOverlays)
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("POCO / Xiaomi HyperOS Survival Actions", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFFF59E0B))
            Text("Vendor-specific intent fallbacks to prevent process termination:", fontSize = 11.sp, color = Color(0xFF94A3B8))
        }

        item {
            Button(
                onClick = { XiaomiHyperOsHelper.openAutostartSettings(context) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("1. Open Autostart Settings", color = Color(0xFF38BDF8))
            }
        }

        item {
            Button(
                onClick = { XiaomiHyperOsHelper.openBatterySaverNoRestrictions(context) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("2. Open Battery Saver ('No restrictions')", color = Color(0xFF38BDF8))
            }
        }

        item {
            Button(
                onClick = { XiaomiHyperOsHelper.openPopUpWindowPermission(context) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("3. Open Pop-up Windows Permission", color = Color(0xFF38BDF8))
            }
        }
    }
}

@Composable
fun PermRow(name: String, granted: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(name, fontSize = 12.sp, color = Color(0xFFCBD5E1), fontFamily = FontFamily.Monospace)
        Surface(
            color = if (granted) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFFEF4444).copy(alpha = 0.2f),
            shape = RoundedCornerShape(4.dp)
        ) {
            Text(
                if (granted) "GRANTED" else "MISSING",
                color = if (granted) Color(0xFF10B981) else Color(0xFFEF4444),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
fun LogsScreen(logs: List<String>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item {
            Text("Live Android Service Logs", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            Text("Real execution messages emitted by Phase0BleService:", fontSize = 12.sp, color = Color(0xFF94A3B8))
        }

        if (logs.isEmpty()) {
            item {
                Text("No service logs yet. Start the service from the top bar.", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        } else {
            items(logs.reversed()) { log ->
                Text(
                    text = log,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (log.contains("ERROR")) Color(0xFFF43F5E) else Color(0xFF94A3B8)
                )
            }
        }
    }
}
