package com.contextpulse.phase0

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log

class Phase0Application : Application() {

    companion object {
        const val CHANNEL_BLE_SERVICE = "channel_ble_service"
        const val CHANNEL_ALERTS = "channel_context_alerts"
        const val TAG = "ContextPulsePhase0"
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Application initialized. Device: ${Build.MANUFACTURER} ${Build.MODEL}, OS: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val serviceChannel = NotificationChannel(
                CHANNEL_BLE_SERVICE,
                "ContextPulse Background Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps BLE room scanning alive in background"
                setShowBadge(false)
            }

            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS,
                "Context Trigger Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications triggered upon room arrival or departure"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(serviceChannel)
            notificationManager.createNotificationChannel(alertsChannel)
        }
    }
}
